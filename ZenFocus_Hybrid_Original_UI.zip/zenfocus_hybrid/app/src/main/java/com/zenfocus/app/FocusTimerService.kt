package com.zenfocus.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

class FocusTimerService : Service() {
    companion object {
        const val ACTION_START = "com.zenfocus.app.START"
        const val ACTION_PAUSE = "com.zenfocus.app.PAUSE"
        const val ACTION_STOP = "com.zenfocus.app.STOP"
        private const val CHANNEL = "zenfocus_timer"
        private const val NOTIFICATION_ID = 4101
    }
    private val handler = Handler(Looper.getMainLooper())
    private var endAt = 0L
    private var remaining = 0L
    private var running = false
    private var mode = "Focus"
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            remaining = ((endAt - System.currentTimeMillis()).coerceAtLeast(0L))
            if (remaining <= 0L) {
                running = false
                handler.removeCallbacks(this)
                val done = NotificationCompat.Builder(this@FocusTimerService, CHANNEL)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setContentTitle("ZenFocus")
                    .setContentText("$mode timer finished")
                    .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_HIGH).build()
                val manager = getSystemService(NotificationManager::class.java)
                manager.notify(NOTIFICATION_ID + 1, done)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            } else {
                showNotification()
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate() { super.onCreate(); createChannel() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                remaining = intent.getLongExtra("seconds", 0L).coerceAtLeast(0L) * 1000L
                mode = intent.getStringExtra("mode") ?: "Focus"
                endAt = System.currentTimeMillis() + remaining
                running = true
                startForeground(NOTIFICATION_ID, buildNotification())
                handler.removeCallbacks(tick); handler.post(tick)
            }
            ACTION_PAUSE -> {
                if (running) remaining = (endAt - System.currentTimeMillis()).coerceAtLeast(0L)
                running = false; handler.removeCallbacks(tick); showNotification()
            }
            ACTION_STOP -> { running = false; handler.removeCallbacks(tick); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        }
        return START_NOT_STICKY
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Focus timer", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun buildNotification(): android.app.Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val pauseIntent = Intent(this, FocusTimerService::class.java).setAction(if (running) ACTION_PAUSE else ACTION_START)
            .putExtra("seconds", (remaining / 1000L).toInt()).putExtra("mode", mode)
        val action = PendingIntent.getService(this, 1, pauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val secs = if (running) ((endAt - System.currentTimeMillis()).coerceAtLeast(0L) / 1000L) else remaining / 1000L
        val time = "%02d:%02d".format(secs / 60, secs % 60)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("ZenFocus • $mode")
            .setContentText("$time remaining")
            .setContentIntent(open).setOngoing(running).setOnlyAlertOnce(true)
            .addAction(0, if (running) "Pause" else "Resume", action)
            .addAction(0, "Stop", PendingIntent.getService(this, 2, Intent(this, FocusTimerService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            .build()
    }
    private fun showNotification() {
        val n = buildNotification()
        if (running) startForeground(NOTIFICATION_ID, n) else getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, n)
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }
}
